---
name: claim-check
description: >-
  当需要检查论文草稿中的事实性论断是否有证据支撑、做引用-论断对齐审计、
  找出没有出处的陈述、核对文内引用是否真能支撑所在句子时加载使用；
  通常由 evidence-loop 或审稿类流程调用，不直接面向用户。同义场景：
  论断支撑检查、claim 支撑审计、无支撑断言排查、证据覆盖检查、
  引用与论断对齐、"这段话有没有文献撑""哪些说法没有引用"。
user-invocable: false
metadata:
  domains: [verification]
  last_reviewed: '2026-08-18'
display_name: "claim-check"
display_name_en: "claim-check"
description_zh: "当需要检查论文草稿中的事实性论断是否有证据支撑、做引用-论断对齐审计、 找出没有出处的陈述、核对文内引用是否真能支撑所在句子时加载使用； 通常由 evidence-loop 或审稿类流程调用，不直接面向用户。同义场景： 论断支撑检查、claim 支撑审计、无支撑断言排查、证据覆盖检查、 引用与论断对齐、\"这段话有没有文献撑\"\"哪些说法没有引用\"。"
description_en: "Workflow skill claim-check. Follow the Chinese instructions in the body."
category: data-analysis
version: 1.0.0
author: Hylouis233
---

# claim-check：正文 claim 支撑检查

## 目的

从论文草稿中抽取事实性 claim，逐条映射其支撑来源（文内文献引用 /
EvidenceItem / 实验数据 / 无支撑），产出无支撑 claim 清单与结构化审查结论。

本技能只回答一个问题：「这句话有没有东西撑着？」
不回答「这句话写得好不好、有没有价值」。

## 前置检查

1. 草稿文件存在且可读（`.md` / `.tex` / 纯文本）。
2. 如存在上游产物，一并读取用于交叉核对：
   - `output/literature-search/<slug>/latest/papers.json`（文献库）；
   - `output/literature-survey/<slug>/latest/evidence.json`（EvidenceItem 库）。
3. 计算 slug，规则与上游技能一致：主题字符串做 Unicode NFKC 规范化、
   转小写、去首尾空白、连续空白折叠为单个空格后，取 sha1 十六进制摘要
   前 8 位。

## 操作规程

### 1. 切分与抽取

- 按「节 → 段 → 句」切分草稿，跳过参考文献节、附录、致谢。
- 抽取事实性 claim：关于外部世界、可被证伪的陈述。典型标志：
  断言某方法优于另一方法、某现象普遍存在、某指标达到某数值、
  「已有研究表明……」「X 已被广泛用于……」等。
- 明确排除三类句子，不进入支撑检查：
  - 观点与立场（「我们认为该方向很有前景」）；
  - 方法描述（「本文采用三层卷积网络」——描述自己的做法，而非外部事实）；
  - 数学定义、符号约定与纯过渡句。

### 2. 支撑映射

对每条事实性 claim，按以下优先级寻找支撑：

1. **文献引用**：句内或句末存在文内引用标记（`[12]`、citekey、
   `(Author, 2023)`）。若存在 papers.json，核对被引对象确实在文献库中；
   不在则记 error（无源引用）。
2. **EvidenceItem**：evidence.json 中存在 paper_id 匹配、且 quote 语义能
   覆盖该 claim 的条目。
3. **实验数据**：claim 明确指向本文自身的图 / 表 / 实验小节
   （「如表 2 所示」「图 3 表明」）。
4. **无支撑**：以上均无。

### 3. 无支撑 claim 清单

对每条无支撑 claim 记录：

- 位置：节标题 + 段落序号 + 句序号；
- claim 原文（逐字引用，不改写、不润色）；
- 所需证据类型：文献引用 / 实验数据 / 统计数据；
- 建议检索关键词（2-4 个英文词，供 evidence-loop 生成定向补检 query）。

### 4. 输出与落盘

- 目录：`output/claim-check/<slug>/latest/`，写入 `unsupported-claims.md`
  与 `review.json`。
- 结论同时以 ```review 块输出，`check` 字段固定为 `citation`：
  - 无支撑事实 claim → level `warn`；若属于关键论断（方法比较、性能断言、
    领域定论类）可升为 `error`；
  - 引用了文献库中不存在的 paper_id / 编号 → level `error`（无源引用）；
  - 有支撑的 claim 不逐条列出，只在统计条目中体现。

### 5. claim 分类示例（抽取时的判定参照）

| 例句 | 分类 | 是否检查 |
| --- | --- | --- |
| "BERT 在 GLUE 基准上取得了当时最优结果" | 事实性 claim | 是 |
| "实验表明本文方法比基线高 2.3 个点" | 事实性 claim（支撑类型：实验数据） | 是 |
| "该数据集已被广泛用于公平性研究" | 事实性 claim | 是 |
| "X 方法是 Y 任务的当前主流方案" | 事实性 claim | 是 |
| "我们认为多模态是最有前景的方向" | 观点立场 | 否 |
| "本文采用三层 BiLSTM 编码句子" | 方法描述 | 否 |
| "令 x 表示输入序列" | 定义约定 | 否 |

判定拿不准时按「保守纳入」处理：宁可误报一条无支撑 claim，也不漏检。
抽取粒度以「句」为最小单位；一句含多个独立事实断言时拆成多条 claim。

### 6. 结果优先级

- 先报 error（无源引用），再报 warn（无支撑 claim），最后给统计；
- 同一位置的多个问题合并为一条，evidence 中注明「同处 N 个问题」；
- 全部有支撑时也要输出一条 ok 级统计，避免「无输出 = 未检查」的歧义；
- 支撑覆盖率低于 80% 时，在最终回复中明确提示「证据基础偏弱」；
- 每条 warn / error 的 title 必须含可定位信息（节名或编号），
  禁止只写「存在问题」之类的空泛表述。

## 输出模板

清单文件开头附统计头：

```markdown
# claim-check 报告：<slug>
- 事实性 claim：23 | 有支撑：20 | 无支撑：3 | 无源引用：1
- 支撑覆盖率：87%
```

### 无支撑 claim 清单（unsupported-claims.md）

| # | 位置 | claim 原文 | 所需证据类型 | 建议检索词 |
| --- | --- | --- | --- | --- |
| 1 | 引言 / 段2 / 句3 | "已有研究表明该方法能将误差降低 30%" | 文献引用 | error reduction; benchmark |
| 2 | 相关工作 / 段1 / 句2 | "现有方法普遍无法处理长序列" | 文献引用 | long sequence; limitation |

### review 块

```review
[
  {"level": "warn", "check": "citation", "title": "引言段2存在无支撑 claim",
   "evidence": "“已有研究表明该方法能将误差降低 30%” 无文内引用、无 EvidenceItem",
   "note": "需要文献引用；建议检索：error reduction benchmark"},
  {"level": "error", "check": "citation", "title": "无源引用 [17]",
   "evidence": "文中引用编号 [17] 在参考文献表与 papers.json 中均无对应条目",
   "note": "删除该引用标记或补充真实来源"},
  {"level": "ok", "check": "citation", "title": "支撑覆盖统计",
   "evidence": "事实性 claim 共 23 条，有支撑 20 条", "note": "覆盖率 87%"}
]
```

## 本技能不做什么

- 不判断 claim 的学术价值、新颖性或表述优劣，只判支撑有无。
- 不核验参考文献条目的元数据真伪（交给 citation-verify）。
- 不主动检索新文献补证据（交给 evidence-loop）。
- 不修改草稿；只产出清单与建议。
- 不检查观点类、方法描述类、定义类句子。
- 不检查图表内容本身的正确性，只确认「指向图表」的引用关系存在。

## 收尾与下一步

1. 汇总：事实性 claim 总数、支撑覆盖率、无支撑条数、无源引用条数，
   回复中附 ```review 块。
2. 指向 `output/claim-check/<slug>/latest/` 产物。
3. 下一步：无支撑条目较多时建议进入 evidence-loop 做定向补检；
   无源引用请用户确认后删除或补源。
4. 若支撑覆盖率为 100%，明确告知用户「本次未发现无支撑问题」，不留歧义。
